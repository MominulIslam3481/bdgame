<?php
include "db.php";

$phone = $_POST['phone'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);

$sql = "INSERT INTO users (phone, password) VALUES ('$phone', '$password')";

if ($conn->query($sql)) {
    echo "Registration successful. <a href='login.html'>Login now</a>";
} else {
    echo "Registration failed. Maybe phone already used.";
}
?>
