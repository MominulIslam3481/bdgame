<?php
include "db.php";

$phone = $_POST['phone'];
$password = $_POST['password'];

$sql = "SELECT * FROM users WHERE phone='$phone'";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
  $user = $result->fetch_assoc();
  if (password_verify($password, $user['password'])) {
    header("Location: home.html");
  } else {
    echo "Wrong password.";
  }
} else {
  echo "User not found.";
}
?>
